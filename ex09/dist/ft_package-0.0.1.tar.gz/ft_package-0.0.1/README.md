# Ft package

This is my custom ft Python package.

## Installation

```bash
pip install ft_package